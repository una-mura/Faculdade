-- Conte quantos produtos foram vendidos

SELECT ROUND(SUM(Quantidade), 2) AS 'Total de Produtos Vendidos' FROM LVP;
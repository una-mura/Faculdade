-- Selecione todas as vendas realizadas hoje

SELECT * FROM venda WHERE DAY(Data) = 17;
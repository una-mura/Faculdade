-- Selecione todos os clientes ordenados por nome de forma crescente 

SELECT * FROM cliente ORDER BY Nome ASC;
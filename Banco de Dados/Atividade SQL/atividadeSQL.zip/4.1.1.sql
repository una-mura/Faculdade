-- Selecione todos os clientes que moram em Cuiabá 

SELECT * FROM Cliente WHERE Cidade = 'Cuiabá';
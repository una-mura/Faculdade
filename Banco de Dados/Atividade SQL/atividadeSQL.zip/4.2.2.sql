-- Selecione todos os clientes ordenadores por cidade e nome, contudo o nome de forma decrescente.

SELECT * FROM cliente ORDER BY Nome DESC, Cidade ASC;
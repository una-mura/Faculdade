-- Selecione todos os produtos que tenha preço maior que 10 reais

SELECT * FROM produto WHERE Preco > 10.00;
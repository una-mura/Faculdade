-- Seleciona todas as vendas realizadas no ano de 2020

SELECT * FROM venda WHERE YEAR(Data) = 2020;